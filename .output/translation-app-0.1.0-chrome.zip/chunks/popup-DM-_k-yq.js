import{a as e,c as t,i as n,l as r,n as i,o as a,r as o,s,t as c}from"./jsx-runtime-CU623aog.js";var l=r(),u=t(),d=new Set([`http:`,`https:`]);function f(e){if(!e)return null;try{let t=new URL(e);return!d.has(t.protocol)||!t.hostname?null:t.hostname.toLowerCase()}catch{return null}}function p(e,t){let n=e.toLowerCase().trim();for(let e of t){let t=e.toLowerCase().trim();if(t&&(n===t||n.endsWith(`.${t}`)))return e}return null}function m(e){if(e.engine===`edge`)return{label:`Edge 免费端点`,ready:!0};let t=e.engines[`openai-compatible`],n=!!t.apiKey.trim(),r=!!t.baseUrl.trim(),i=t.model.trim();return n?!r||!i?{label:`OpenAI 兼容（配置不完整）`,ready:!1}:{label:`OpenAI 兼容 · ${i}`,ready:!0}:{label:`OpenAI 兼容（未配置密钥）`,ready:!1}}function h(e,t){let n=f(t),r=n!==null,i=n?p(n,e.blockedHosts):null,a=n?!o(n,e.blockedHosts):!1,c=m(e),l=s.find(t=>t.code===e.targetLanguage)?.label??e.targetLanguage;return{selectionTranslate:e.features.selectionTranslate,youtubeSubtitles:e.features.youtubeSubtitles,siteHost:n,siteSupported:r,siteEnabled:a,matchedBlockRule:i,engineId:e.engine,engineLabel:c.label,engineReady:c.ready,targetLanguage:e.targetLanguage,targetLanguageLabel:l}}function g(e,t,n){return{...e,features:{...e.features,[t]:n}}}function _(e,t,n){let r=t.toLowerCase().trim();return r?n?{...e,blockedHosts:e.blockedHosts.filter(e=>{let t=e.toLowerCase().trim();return!(r===t||r.endsWith(`.${t}`))})}:o(r,e.blockedHosts)?e:{...e,blockedHosts:[...e.blockedHosts,r]}:e}async function v(){try{return(await i.tabs.query({active:!0,currentWindow:!0}))[0]?.url}catch{return}}async function y(){if(typeof i.runtime.openOptionsPage==`function`){await i.runtime.openOptionsPage();return}let e=i.runtime.getURL(`/options.html`);window.open(e,`_blank`)}var b=c(),x=`
  .popup-root {
    width: 288px;
    padding: 14px 16px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
    color: #1f2937;
    box-sizing: border-box;
  }
  .popup-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 12px;
  }
  .popup-title {
    font-size: 15px;
    font-weight: 700;
    letter-spacing: -0.01em;
  }
  .popup-link-btn {
    border: 1px solid #e5e7eb;
    background: #f9fafb;
    color: #374151;
    font-size: 12px;
    padding: 4px 10px;
    border-radius: 6px;
    cursor: pointer;
  }
  .popup-link-btn:hover {
    background: #f3f4f6;
  }
  .popup-status {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    padding: 8px 10px;
    margin-bottom: 12px;
    font-size: 12px;
  }
  .popup-status-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
  }
  .popup-status-row + .popup-status-row {
    margin-top: 4px;
  }
  .popup-muted {
    color: #64748b;
  }
  .popup-engine {
    font-weight: 600;
    color: #0f172a;
  }
  .popup-engine.warn {
    color: #dc2626;
  }
  .popup-section {
    border-top: 1px solid #f1f5f9;
    padding-top: 8px;
    margin-top: 8px;
  }
  .popup-toggle {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 6px 0;
    font-size: 13px;
    cursor: pointer;
    user-select: none;
  }
  .popup-toggle input {
    width: 16px;
    height: 16px;
    accent-color: #2563eb;
    cursor: pointer;
  }
  .popup-host {
    font-size: 12px;
    color: #6b7280;
    margin-top: 2px;
    word-break: break-all;
  }
  .popup-error {
    color: #dc2626;
    font-size: 12px;
  }
`;function S({getActiveTabUrl:t=v,openOptions:r=y}={}){let[i,o]=(0,l.useState)(null),[s,c]=(0,l.useState)(void 0),[u,d]=(0,l.useState)(!1);if((0,l.useEffect)(()=>{let e=!0;Promise.all([n(),t()]).then(([t,n])=>{e&&(o(t),c(n))},()=>{e&&d(!0)});let r=a(t=>{e&&o(t)});return()=>{e=!1,r()}},[t]),u)return(0,b.jsxs)(`main`,{className:`popup-root`,children:[(0,b.jsx)(`style`,{children:x}),(0,b.jsx)(`p`,{className:`popup-error`,children:`配置读取失败，请重新打开弹窗或前往扩展设置页重试。`})]});if(!i)return(0,b.jsxs)(`main`,{className:`popup-root`,children:[(0,b.jsx)(`style`,{children:x}),(0,b.jsx)(`span`,{className:`popup-muted`,children:`加载中…`})]});let f=h(i,s),p=async t=>{o(t),await e(t)},m=(e,t)=>{p(g(i,e,t))},S=e=>{f.siteHost&&p(_(i,f.siteHost,e))};return(0,b.jsxs)(`main`,{className:`popup-root`,children:[(0,b.jsx)(`style`,{children:x}),(0,b.jsxs)(`header`,{className:`popup-header`,children:[(0,b.jsx)(`span`,{className:`popup-title`,children:`translationApp`}),(0,b.jsx)(`button`,{type:`button`,className:`popup-link-btn`,onClick:()=>void r(),children:`打开设置`})]}),(0,b.jsxs)(`section`,{className:`popup-status`,"aria-label":`当前引擎状态`,children:[(0,b.jsxs)(`div`,{className:`popup-status-row`,children:[(0,b.jsx)(`span`,{className:`popup-muted`,children:`当前引擎`}),(0,b.jsx)(`span`,{className:`popup-engine${f.engineReady?``:` warn`}`,children:f.engineLabel})]}),(0,b.jsxs)(`div`,{className:`popup-status-row`,children:[(0,b.jsx)(`span`,{className:`popup-muted`,children:`目标语言`}),(0,b.jsx)(`span`,{children:f.targetLanguageLabel})]})]}),(0,b.jsxs)(`section`,{"aria-label":`全局开关`,children:[(0,b.jsxs)(`label`,{className:`popup-toggle`,children:[(0,b.jsx)(`span`,{children:`划词翻译`}),(0,b.jsx)(`input`,{type:`checkbox`,checked:f.selectionTranslate,onChange:e=>m(`selectionTranslate`,e.target.checked)})]}),(0,b.jsxs)(`label`,{className:`popup-toggle`,children:[(0,b.jsx)(`span`,{children:`YouTube 双语字幕`}),(0,b.jsx)(`input`,{type:`checkbox`,checked:f.youtubeSubtitles,onChange:e=>m(`youtubeSubtitles`,e.target.checked)})]})]}),(0,b.jsx)(`section`,{className:`popup-section`,"aria-label":`当前站点开关`,children:f.siteSupported&&f.siteHost?(0,b.jsxs)(b.Fragment,{children:[(0,b.jsxs)(`label`,{className:`popup-toggle`,children:[(0,b.jsx)(`span`,{children:`在此站点启用`}),(0,b.jsx)(`input`,{type:`checkbox`,checked:f.siteEnabled,onChange:e=>S(e.target.checked)})]}),(0,b.jsxs)(`div`,{className:`popup-host`,children:[f.siteHost,!f.siteEnabled&&f.matchedBlockRule&&f.matchedBlockRule!==f.siteHost?`（命中黑名单：${f.matchedBlockRule}）`:``]})]}):(0,b.jsx)(`div`,{className:`popup-host`,children:`当前浏览器内置页不支持注入翻译脚本`})})]})}var C=document.getElementById(`root`);C&&(0,u.createRoot)(C).render((0,b.jsx)(S,{}));
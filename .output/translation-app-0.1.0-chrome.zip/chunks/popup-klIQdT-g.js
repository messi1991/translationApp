import{a as e,c as t,i as n,l as r,n as i,o as a,r as o,s,t as c,u as l}from"./jsx-runtime-B5dmuafM.js";var u=l(),d=r(),f=new Set([`http:`,`https:`]);function p(e){if(!e)return null;try{let t=new URL(e);return!f.has(t.protocol)||!t.hostname?null:t.hostname.toLowerCase()}catch{return null}}function m(e,t){let n=e.toLowerCase().trim();for(let e of t){let t=e.toLowerCase().trim();if(t&&(n===t||n.endsWith(`.${t}`)))return e}return null}function h(e,t){if(t===`edge`)return{id:`edge`,label:`Edge 免费端点`,ready:!0};let n=e.engines[`openai-compatible`],r=!!n.apiKey.trim(),i=!!n.baseUrl.trim(),a=n.model.trim();return r?!i||!a?{id:`openai-compatible`,label:`OpenAI 兼容（配置不完整）`,ready:!1}:{id:`openai-compatible`,label:`OpenAI 兼容 · ${a}`,ready:!0}:{id:`openai-compatible`,label:`OpenAI 兼容（未配置密钥）`,ready:!1}}function g(e,t){let n=p(t),r=n!==null,i=n?m(n,e.blockedHosts):null,a=n?!o(n,e.blockedHosts):!1,c=[h(e,`edge`),h(e,`openai-compatible`)],l=c.find(t=>t.id===e.engine)??h(e,e.engine),u=s.find(t=>t.code===e.targetLanguage)?.label??e.targetLanguage;return{selectionTranslate:e.features.selectionTranslate,youtubeSubtitles:e.features.youtubeSubtitles,siteHost:n,siteSupported:r,siteEnabled:a,matchedBlockRule:i,engineId:e.engine,engineLabel:l.label,engineReady:l.ready,engineOptions:c,targetLanguage:e.targetLanguage,targetLanguageLabel:u}}function _(e,t){let n=t===`openai-compatible`?`openai-compatible`:`edge`;return n===e.engine?e:{...e,engine:n}}function v(e,n){let r=t(n);return r===e.targetLanguage?e:{...e,targetLanguage:r}}function y(e,t,n){return{...e,features:{...e.features,[t]:n}}}function b(e,t,n){let r=t.toLowerCase().trim();return r?n?{...e,blockedHosts:e.blockedHosts.filter(e=>{let t=e.toLowerCase().trim();return!(r===t||r.endsWith(`.${t}`))})}:o(r,e.blockedHosts)?e:{...e,blockedHosts:[...e.blockedHosts,r]}:e}async function x(){try{return(await i.tabs.query({active:!0,currentWindow:!0}))[0]?.url}catch{return}}async function S(){if(typeof i.runtime.openOptionsPage==`function`){await i.runtime.openOptionsPage();return}let e=i.runtime.getURL(`/options.html`);window.open(e,`_blank`)}var C=c(),w=`
  .popup-root {
    width: 288px;
    padding: 14px 16px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
    color: #1f2937;
    box-sizing: border-box;
  }
  .popup-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 12px;
  }
  .popup-title {
    font-size: 15px;
    font-weight: 700;
    letter-spacing: -0.01em;
  }
  .popup-link-btn {
    border: 1px solid #e5e7eb;
    background: #f9fafb;
    color: #374151;
    font-size: 12px;
    padding: 4px 10px;
    border-radius: 6px;
    cursor: pointer;
  }
  .popup-link-btn:hover {
    background: #f3f4f6;
  }
  .popup-status {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    padding: 8px 10px;
    margin-bottom: 12px;
    font-size: 12px;
  }
  .popup-status-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
  }
  .popup-status-row + .popup-status-row {
    margin-top: 6px;
  }
  .popup-muted {
    color: #64748b;
    flex-shrink: 0;
  }
  .popup-select {
    padding: 3px 6px;
    border: 1px solid #cbd5e1;
    border-radius: 5px;
    background: #ffffff;
    color: #0f172a;
    font-size: 12px;
    width: 168px;
    max-width: 168px;
    cursor: pointer;
    text-overflow: ellipsis;
  }
  .popup-select.warn {
    border-color: #fca5a5;
    color: #dc2626;
  }
  .popup-warn-hint {
    margin-top: 6px;
    font-size: 11px;
    color: #dc2626;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 6px;
  }
  .popup-inline-link {
    border: none;
    background: none;
    color: #2563eb;
    font-size: 11px;
    padding: 0;
    cursor: pointer;
    text-decoration: underline;
    flex-shrink: 0;
  }
  .popup-section {
    border-top: 1px solid #f1f5f9;
    padding-top: 8px;
    margin-top: 8px;
  }
  .popup-toggle {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 6px 0;
    font-size: 13px;
    cursor: pointer;
    user-select: none;
  }
  .popup-toggle input {
    width: 16px;
    height: 16px;
    accent-color: #2563eb;
    cursor: pointer;
  }
  .popup-host {
    font-size: 12px;
    color: #6b7280;
    margin-top: 2px;
    word-break: break-all;
  }
  .popup-error {
    color: #dc2626;
    font-size: 12px;
  }
`;function T({getActiveTabUrl:t=x,openOptions:r=S}={}){let[i,o]=(0,u.useState)(null),[c,l]=(0,u.useState)(void 0),[d,f]=(0,u.useState)(!1);if((0,u.useEffect)(()=>{let e=!0;Promise.all([n(),t()]).then(([t,n])=>{e&&(o(t),l(n))},()=>{e&&f(!0)});let r=a(t=>{e&&o(t)});return()=>{e=!1,r()}},[t]),d)return(0,C.jsxs)(`main`,{className:`popup-root`,children:[(0,C.jsx)(`style`,{children:w}),(0,C.jsx)(`p`,{className:`popup-error`,children:`配置读取失败，请重新打开弹窗或前往扩展设置页重试。`})]});if(!i)return(0,C.jsxs)(`main`,{className:`popup-root`,children:[(0,C.jsx)(`style`,{children:w}),(0,C.jsx)(`span`,{className:`popup-muted`,children:`加载中…`})]});let p=g(i,c),m=async t=>{o(t),await e(t)},h=e=>{m(_(i,e))},T=e=>{m(v(i,e))},E=(e,t)=>{m(y(i,e,t))},D=e=>{p.siteHost&&m(b(i,p.siteHost,e))};return(0,C.jsxs)(`main`,{className:`popup-root`,children:[(0,C.jsx)(`style`,{children:w}),(0,C.jsxs)(`header`,{className:`popup-header`,children:[(0,C.jsx)(`span`,{className:`popup-title`,children:`translationApp`}),(0,C.jsx)(`button`,{type:`button`,className:`popup-link-btn`,onClick:()=>void r(),children:`打开设置`})]}),(0,C.jsxs)(`section`,{className:`popup-status`,"aria-label":`当前引擎状态`,children:[(0,C.jsxs)(`div`,{className:`popup-status-row`,children:[(0,C.jsx)(`label`,{htmlFor:`popup-engine`,className:`popup-muted`,children:`当前引擎`}),(0,C.jsx)(`select`,{id:`popup-engine`,"aria-label":`当前引擎`,className:`popup-select${p.engineReady?``:` warn`}`,value:p.engineId,onChange:e=>h(e.target.value),children:p.engineOptions.map(e=>(0,C.jsx)(`option`,{value:e.id,children:e.label},e.id))})]}),!p.engineReady&&(0,C.jsxs)(`div`,{className:`popup-warn-hint`,children:[(0,C.jsx)(`span`,{children:`当前引擎尚未完成 API 配置`}),(0,C.jsx)(`button`,{type:`button`,className:`popup-inline-link`,onClick:()=>void r(),children:`去配置`})]}),(0,C.jsxs)(`div`,{className:`popup-status-row`,children:[(0,C.jsx)(`label`,{htmlFor:`popup-target-language`,className:`popup-muted`,children:`目标语言`}),(0,C.jsxs)(`select`,{id:`popup-target-language`,"aria-label":`目标语言`,className:`popup-select`,value:p.targetLanguage,onChange:e=>T(e.target.value),children:[!s.some(e=>e.code===p.targetLanguage)&&(0,C.jsx)(`option`,{value:p.targetLanguage,children:p.targetLanguageLabel}),s.map(e=>(0,C.jsx)(`option`,{value:e.code,children:e.label},e.code))]})]})]}),(0,C.jsxs)(`section`,{"aria-label":`全局开关`,children:[(0,C.jsxs)(`label`,{className:`popup-toggle`,children:[(0,C.jsx)(`span`,{children:`划词翻译`}),(0,C.jsx)(`input`,{type:`checkbox`,checked:p.selectionTranslate,onChange:e=>E(`selectionTranslate`,e.target.checked)})]}),(0,C.jsxs)(`label`,{className:`popup-toggle`,children:[(0,C.jsx)(`span`,{children:`YouTube 双语字幕`}),(0,C.jsx)(`input`,{type:`checkbox`,checked:p.youtubeSubtitles,onChange:e=>E(`youtubeSubtitles`,e.target.checked)})]})]}),(0,C.jsx)(`section`,{className:`popup-section`,"aria-label":`当前站点开关`,children:p.siteSupported&&p.siteHost?(0,C.jsxs)(C.Fragment,{children:[(0,C.jsxs)(`label`,{className:`popup-toggle`,children:[(0,C.jsx)(`span`,{children:`在此站点启用`}),(0,C.jsx)(`input`,{type:`checkbox`,checked:p.siteEnabled,onChange:e=>D(e.target.checked)})]}),(0,C.jsxs)(`div`,{className:`popup-host`,children:[p.siteHost,!p.siteEnabled&&p.matchedBlockRule&&p.matchedBlockRule!==p.siteHost?`（命中黑名单：${p.matchedBlockRule}）`:``]})]}):(0,C.jsx)(`div`,{className:`popup-host`,children:`当前浏览器内置页不支持注入翻译脚本`})})]})}var E=document.getElementById(`root`);E&&(0,d.createRoot)(E).render((0,C.jsx)(T,{}));